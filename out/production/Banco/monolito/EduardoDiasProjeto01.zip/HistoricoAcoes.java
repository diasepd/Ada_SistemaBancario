package monolito;

import java.util.ArrayList;

public class HistoricoAcoes {
    ArrayList<Acao> acao = new ArrayList<Acao>();
}
