package monolito;

public class Acao {
    String data;
    String tipo;
    String valorPretendido;
    String valorReal;
    String usuarioOrigem;
    String usuarioDestino;
    String observacao;
}
